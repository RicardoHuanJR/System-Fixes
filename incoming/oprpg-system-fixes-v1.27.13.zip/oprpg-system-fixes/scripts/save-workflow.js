import { MODULE_ID, STATE, getCardActivity } from './shared.js';
import { messageAudience, showPrivateDice } from './roll-privacy.js';
import { rollSelectedActivityDamage, applyDamageState, damageStateForCard, prepareSaveDamageCard } from './multi-activity-damage-fix.js';
import { targetActors } from './target-damage.js';
import { styleSaveDamageButton } from './presentation.js';
import { areaExecution, areaProtected, executionActors } from './area-state.js';
import { isCasterActor } from './area-caster.js';
import { runItemMacros } from './external-compatibility.js';

const busy=new Set();
let installed=false;
const esc=value=>foundry.utils.escapeHTML(String(value??''));
export function sourceCard(message, activityId=null) {
  const root=document.createElement('div');root.innerHTML=message?.content??'';
  const cards=Array.from(root.querySelectorAll('.jujutsu-card[data-card-type="save"]'));
  // A request for activity B must never silently roll activity A's ability/DC.
  // When B is absent, let the independently authorized request supply its
  // recorded configuration, or fail closed if no such request exists.
  return activityId ? cards.find(card=>card.dataset.activityId===activityId)??null : cards[0]??null;
}
export function hasCompletedSave(message,card,extra=null) {
  if(!message?.id || !card?.dataset.activityId)return false;
  const matches=result=>{
    const info=result?.getFlag?.(MODULE_ID,'saveResult');
    return info?.source===message.id && info.key?.startsWith(`${message.id}:${card.dataset.activityId}:`) && Number.isFinite(info.total);
  };
  return matches(extra)||Array.from(game.messages??[]).some(matches);
}
export function refreshSaveDamageButton(message,card,extra=null) {
  const ready=hasCompletedSave(message,card,extra);
  const existing=card.querySelector('[data-action="jj-save-damage"]');
  if(!ready){existing?.remove();return false;}
  const {activity}=getCardActivity(card);
  if(activity?.damage?.parts?.length && !existing){
    const button=document.createElement('button');button.type='button';button.dataset.action='jj-save-damage';card.append(button);styleSaveDamageButton(button);
  }
  if(existing)styleSaveDamageButton(existing);
  return ready;
}
function refreshSourceForResult(result,includeResult=true) {
  const info=result?.getFlag?.(MODULE_ID,'saveResult'),source=info&&game.messages.get(info.source);
  if(!source || source.isContentVisible===false)return;
  for(const element of document.querySelectorAll('[data-message-id]')){
    if(element.dataset.messageId!==source.id)continue;
    const activityId=String(info.key??'').slice(`${source.id}:`.length).split(':')[0];
    for(const card of element.querySelectorAll('.jujutsu-card[data-card-type="save"]')){
      if(card.dataset.activityId===activityId)
        refreshSaveDamageButton(source,card,includeResult?result:null);
    }
  }
}
export function saveConfiguration(card) {
  const {activity}=getCardActivity(card);
  const abilities=activity?.save?.ability;
  const ability=typeof abilities==='string'?abilities:Array.from(abilities??[])[0];
  const dc=Number(activity?.save?.dc?.value ?? activity?.save?.dc);
  if(!ability || !CONFIG.DND5E.abilities[ability] || !Number.isFinite(dc) || dc<=0)throw Error('Configure o atributo e a CD da salvaguarda na atividade.');
  return {ability,dc};
}
export async function rollSaveForActor(actor,source,requestInfo=null) {
  if(!actor?.isOwner || source?.isContentVisible===false&&!requestInfo?.authorizedRequest)throw Error('Você precisa controlar a ficha e poder ver o cartão da técnica.');
  const execution=areaExecution(source);
  if(execution&&(execution.status!=='ready'||!execution.targets.includes(actor.uuid)||areaProtected(source,actor)||isCasterActor(actor,execution)))throw Error('Este alvo não precisa rolar a salvaguarda desta execução.');
  const card=source?.isContentVisible===false?null:sourceCard(source,requestInfo?.activityId??null);
  if(!card&&source?.isContentVisible!==false&&requestInfo?.activityId)
    throw Error('A atividade solicitada não está mais presente no cartão visível; peça uma nova solicitação.');
  let spec;try{spec=saveConfiguration(card);}catch(error){if(!requestInfo?.ability||!CONFIG.DND5E.abilities[requestInfo.ability]||!Number.isFinite(requestInfo.dc)||requestInfo.dc<=0)throw error;spec=requestInfo;}
  const {ability,dc}=spec,activityId=requestInfo?.activityId??card?.dataset.activityId;
  if(!activityId)throw Error('Atividade da salvaguarda indisponível.');
  const key=`${source.id}:${activityId}:${actor.uuid}`;
  if(busy.has(key))return null;
  const previous=Array.from(game.messages??[]).find(m=>m.getFlag?.(MODULE_ID,'saveResult')?.key===key);
  if(previous){ui.notifications.info(`${actor.name}: salvaguarda já registrada para este cartão.`);return previous;}
  busy.add(key);
  try {
    const {item,activity}=getCardActivity(card);
    const macros=game.settings.get(MODULE_ID,'compatibilityMacros')===true&&item?.isOwner&&item.flags?.['midi-qol']?.onUseMacroName;
    if(macros){const results=await runItemMacros(item,'preSave',{activity,target:actor,source});if(results.some(r=>r===false))return null;}
    // Native saves include proficiency, effects, advantage and Haki modifiers.
    const rolls=await actor.rollSavingThrow({ability,target:dc}, {}, {create:false});
    if(!rolls?.length)return null;
    const audience=requestInfo?.authorizedRequest&&messageAudience(source).whisper.length?messageAudience(requestInfo.authorizedRequest):messageAudience(source);
    const total=Number(rolls[0].total);
    const result=await ChatMessage.create({speaker:ChatMessage.getSpeaker({actor}),rolls,
      whisper:audience.whisper,blind:audience.blind,
      flavor:`${esc(actor.name)} — Salvaguarda ${esc(CONFIG.DND5E.abilities[ability].label??ability)} · CD ${dc} · ${total>=dc?'Sucesso':'Falha'}`,
      flags:{[MODULE_ID]:{saveResult:{key,source:source.id,actor:actor.uuid,ability,dc,total,success:total>=dc}},dnd5e:{messageType:'roll',roll:{type:'save',ability}},OPRPG:{roll:{type:'save',ability}}}});
    refreshSourceForResult(result);
    if(macros)await runItemMacros(item,'postSave',{activity,target:actor,source,rolls,success:total>=dc});
    for(const roll of rolls)await showPrivateDice(roll,{actor,message:result});
    return result;
  } finally {busy.delete(key);}
}
export function saveRequestRecipients(actor,source,users=game.users) {
  // The test invitation is independent of the attack card's private audience.
  return [...new Set(Array.from(users??[]).filter(u=>u.isGM||actor.testUserPermission?.(u,'OWNER')).map(u=>u.id))];
}
export async function requestIndividualSaves(card,source,actors) {
  if(!game.user.isGM&&source.author?.id!==game.user.id)throw Error('O autor da técnica ou o mestre deve solicitar os testes; use o seu pedido individual para rolar.');
  if(!areaExecution(source)){
    const {activity}=getCardActivity(card);saveConfiguration(card);
    await source.setFlag(MODULE_ID,'targetExecution',{status:'ready',sourceId:source.id,activityId:card.dataset.activityId,activityUuid:activity?.uuid,targets:[...new Set(actors.map(a=>a.uuid))],protected:[],templates:[]});
  }
  const results=[];
  for(const actor of actors) {
    const key=`${source.id}:${card.dataset.activityId}:${actor.uuid}`;
    const messages=Array.from(game.messages??[]);
    const previous=messages.find(m=>m.getFlag?.(MODULE_ID,'saveResult')?.key===key)??messages.find(m=>m.getFlag?.(MODULE_ID,'saveRequest')?.key===key);
    if(previous?.getFlag?.(MODULE_ID,'saveResult')){results.push(previous);continue;}
    const recipients=saveRequestRecipients(actor,source);
    if(!recipients.length){ui.notifications.warn(`${actor.name}: nenhum usuário controla a ficha para receber a solicitação.`);continue;}
    const {ability,dc}=saveConfiguration(card);
    const data={whisper:recipients,blind:false,
      content:`<div class="jujutsu-card oprpg-fixes-notice oprpg-save-request"><div class="jj-top"><strong class="jj-top-name">${esc(actor.name)} — Salvaguarda</strong></div><div class="jj-description"><p>${esc(CONFIG.DND5E.abilities[ability].label??ability)} · CD ${dc}</p></div><button class="oprpg-fixes-notice-action" type="button" data-fixes-save-actor="${esc(actor.uuid)}">Rolar salvaguarda</button></div>`,
      flags:{[MODULE_ID]:{saveRequest:{key,source:source.id,activityId:card.dataset.activityId,ability,dc,targets:[actor.uuid],requestedBy:previous?.author?.id??game.user.id,independent:true}}}};
    if(previous){await previous.update(data);results.push(previous);}else results.push(await ChatMessage.create(data));
  }
  return results;
}
export async function rollTargetSaves(card,source,actors=targetActors(),{individual=true}={}) {
  actors=await executionActors(source,actors);
  if(!actors.length)throw Error('Marque todos os alvos da técnica com T antes de pedir as salvaguardas.');
  saveConfiguration(card);
  if(!source || source.isContentVisible===false)throw Error('Cartão de origem indisponível.');
  if(individual||areaExecution(source))return requestIndividualSaves(card,source,actors);
  const pending=actors.filter(a=>!a.isOwner);
  if(pending.length) {
    const audience=messageAudience(source);
    // A request does not grant permission: each button checks the target owner.
    await ChatMessage.create({whisper:audience.whisper,blind:audience.blind,
      content:`<div class="oprpg-save-request"><strong>Salvaguardas pendentes</strong>${pending.map(a=>`<p>${esc(a.name)} <button type="button" data-fixes-save-actor="${esc(a.uuid)}">Rolar salvaguarda</button></p>`).join('')}</div>`,
      flags:{[MODULE_ID]:{saveRequest:{source:source.id,targets:pending.map(a=>a.uuid)}}}});
  }
  const results=[];
  for(const actor of actors)if(actor.isOwner) {
    try {results.push(await rollSaveForActor(actor,source));}
    catch(error){STATE.warnings.push(`Salvaguarda de ${actor.name}: ${error.message}`);ui.notifications.error(`${actor.name}: ${error.message}. Os demais alvos continuam.`);}
  }
  return results;
}
export async function resolveSaveRequest(request,uuid) {
  const info=request?.getFlag(MODULE_ID,'saveRequest');
  if(!info?.targets?.includes(uuid) || request.isContentVisible===false)throw Error('Alvo ausente desta solicitação.');
  const actor=await fromUuid(uuid);let source=game.messages.get(info.source);
  if(!actor?.isOwner)throw Error('Você precisa controlar a ficha do alvo.');
  if(info.independent){
    const author=request.author;
    if(!author?.id||author.id!==info.requestedBy||(!author.isGM&&author.id!==source?.author?.id))throw Error('Solicitação de salvaguarda sem autor autorizado.');
    if(info.key!==`${info.source}:${info.activityId}:${uuid}`||info.targets.length!==1)throw Error('Solicitação de salvaguarda inválida.');
    // A private GM attack may not exist in the player's message collection.
    // Use only the minimal invitation snapshot, never reveal the attack card.
    if(!source)source={id:info.source,isContentVisible:false,whisper:Array.from(request.whisper??[],u=>typeof u==='string'?u:u.id),blind:false,content:''};
    if(areaProtected(source,actor))throw Error('Alvo protegido pelo Controle Cirúrgico.');
    return rollSaveForActor(actor,source,{...info,authorizedRequest:request});
  }
  if(!source || source.isContentVisible===false)throw Error('Cartão de origem indisponível.');
  if(areaProtected(source,actor))throw Error('Alvo protegido pelo Controle Cirúrgico.');
  return rollSaveForActor(actor,source,info);
}
export async function rollSaveDamage(card,message,{scalePrompt=null}={}) {
  const {actor,item,activity}=getCardActivity(card);
  if(!actor?.isOwner || message.isContentVisible===false || (!game.user.isGM&&message.author?.id!==game.user.id))throw Error('O dano deve ser rolado pelo autor da técnica ou pelo mestre.');
  if(!hasCompletedSave(message,card))throw Error('Conclua uma salvaguarda desta técnica antes de rolar o dano.');
  if(!scalePrompt){const native=await import('/systems/oprpg-system/module/applications/actor/jj/jj-scale.mjs');scalePrompt=native.promptJJScale;}
  const scale=await scalePrompt({actor,activity});
  if(scale===null)return null;
  card.dataset.isSpell=String(item.type==='spell');
  card.dataset.jjScaleBonus=scale?.bonusFormula??'';
  prepareSaveDamageCard(card);
  return rollSelectedActivityDamage(card,actor,item,activity);
}
export function installSaveWorkflow() {
  if(installed)return;installed=true;
  Hooks.on('renderChatMessageHTML',(message,html)=>{
    const root=html instanceof HTMLElement?html:html?.[0];
    if(!root || message.isContentVisible===false)return;
    // A single message may contain multiple save cards. Hydrate each one
    // separately instead of silently updating only the first card.
    const cards = [...(root.matches?.('.jujutsu-card[data-card-type="save"]') ? [root] : []),
      ...(root.querySelectorAll?.('.jujutsu-card[data-card-type="save"]') ?? [])];
    for (const card of cards) {
      refreshSaveDamageButton(message,card);
      const state=damageStateForCard(message,card);
      if(state){prepareSaveDamageCard(card);applyDamageState(card,state);card.querySelector('[data-fixes-save-footer]')?.classList.add('visible');}
    }
  });
  // A target owner may finish the save on a different client. Unlock the source
  // card when that result reaches this client, without changing its document.
  Hooks.on('createChatMessage',result=>refreshSourceForResult(result));
  Hooks.on('deleteChatMessage',result=>refreshSourceForResult(result,false));
  document.addEventListener('click',event=>{
    const requestButton=event.target.closest?.('[data-fixes-save-actor]');
    if(requestButton){event.preventDefault();event.stopImmediatePropagation();const request=game.messages.get(requestButton.closest('[data-message-id]')?.dataset.messageId);
      void resolveSaveRequest(request,requestButton.dataset.fixesSaveActor).catch(e=>ui.notifications.error(e.message));return;}
    const button=event.target.closest?.('[data-action]'),card=button?.closest('.jujutsu-card[data-card-type="save"]');
    if(!card || !['jj-extra-roll','jj-save-damage'].includes(button.dataset.action))return;
    event.preventDefault();event.stopImmediatePropagation();
    const message=game.messages.get(card.closest('[data-message-id]')?.dataset.messageId),key=message?.id+':'+button.dataset.action;
    if(busy.has(key))return;busy.add(key);button.disabled=true;
    const action=button.dataset.action==='jj-extra-roll'?rollTargetSaves(card,message):rollSaveDamage(card,message);
    void action.catch(e=>{STATE.warnings.push(e.message);ui.notifications.error(e.message)}).finally(()=>{busy.delete(key);button.disabled=false});
  },true);
  STATE.saveWorkflowPatch=true;
}
